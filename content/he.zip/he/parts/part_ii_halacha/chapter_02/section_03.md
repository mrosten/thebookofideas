---
title: "Chapter 2: Prayer — סעיף III"
part: "חלק ב' — הלכה"
chapter: "פרק 2"
prev: ""
next: ""
---

            

<p>Shemone Esre once a day. It seems to me that it is better not to say the blessing to curse the slanderers since it doesn't do any good to curse ones enemies and the curse just returns on oneself if he is not worthy on any future day. Don't pray for a true soul mate for the Rambam says there is no such thing [in the eight chapters (and Rabbi Nachman agrees). So, you just won't get married at all since there is no true mate. Rather man has complete free will to choose who to marry. Only in what happens to one he has no free will, not in things one does.</p>
            
            
        </div>

</div>

        </div>

        

