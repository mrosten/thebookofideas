---
title: "פרק 11: על המדע — סעיף I"
part: "חלק א' — פילוסופיה"
chapter: "פרק 11"
prev: ""
next: ""
---

            

<blockquote class="fancy-quote">
            "התחקות אחר חוכמת הבורא היא הדרך הקרובה ביותר לבהירות." — חובות הלבבות.
            </blockquote>
            <h4>ההיררכיה של ההבנה</h4>
            <p>הרמב"ם יצר מפה ברורה של הקרבה האנושית לשכל האלוהי. בהיררכיה זו, הלימוד הפשוט של החוק (מלכות) הוא היסוד, אך החקירה של מדע הפיזיקה והלוגיקה (בינה) היא משרה רוחנית גבוהה יותר. להכיר את ה"פרדס"—הבוסתן של הפיזיקה, האסטרונומיה והכימיה—זה לחזות בכוחו הנצחי של הבורא דרך הדברים שעשה.</p>
            <div class="justice-balance">
            <input type="radio" name="science-view" id="view-hierarchy" class="balance-toggle" checked>
            <input type="radio" name="science-view" id="view-vessel" class="balance-toggle">
            <div class="balance-controls">
            <label for="view-hierarchy" class="balance-label label-righteous">היררכיה</label>
            <label for="view-vessel" class="balance-label label-righteous">הכלי</label>
            </div>
            <div class="consequence-grid">
            <div class="consequence-box earth-box" style="grid-column: span 2;">
            <div id="panel-hierarchy">
            <h5>קרבה למלך</h5>
            <ol class="clean-list">
            <li><strong>נביאים:</strong> תפיסה ישירה של הכתר.</li>
            <li><strong>פילוסופים:</strong> אנכיות שכלית.</li>
            <li><strong>מדענים:</strong> הבנת התוכנית.</li>
            <li><strong>למדני תלמוד:</strong> ידע טכני של הקוד.</li>
            </ol>
            <p><span class="status-badge badge-reward">התעלות</span> </div>
            <div id="panel-vessel" style="display:none">
            <h5>מעשים ואור</h5>
            <p>מעשי תורה (מצוות) יוצרים את הכלים, אך מדע ופילוסופיה מושכים את האור לתוכם. ביחס ישר לידיעתו של אדם את טבע העולם, כך העולם כפוף לרצונו.</p>
            <span class="status-badge badge-reward">שליטה</span>
            </div>
            </div> </div> </div>
            <script>
            document.querySelectorAll('input[name="science-view"]').forEach(radio => {
            radio.addEventListener('change', () => {
            const isHierarchy = document.getElementById('view-hierarchy').checked;
            document.getElementById('panel-hierarchy').style.display = isHierarchy ? 'block' : 'none';
            document.getElementById('panel-vessel').style.display = isHierarchy ? 'none' : 'block';
            });
            });
            </script>
            <h4>תזוזת הנשמה</h4>
            <p>היסטורית, לאחר כישלון מרד בר כוכבא, האישיות היהודית עברה מחיפוש רחב ולאומי אחר האמת למיקוד מבודד ומגן בתורה שבעל פה. הפרויקט של הרמב"ם היה היפוך של מגמה זו. הוא הזכיר לנו שבעוד המצוות הן המבנה ההכרחי (מלכות), המדע הוא המהות (בינה). בדיוק כפי שזהב שווה יותר לכמות מאשר כסף, מילה אחת של תובנה מדעית עמוקה יכולה לשאת משקל רוחני רב יותר מכרכים של לגליזם טכני—בתנאי שהכוונה היא לעבוד דרך סקרנות.</p>
            <div class="concept-box">
            <strong>הנתיב האנכי</strong>
            התורה שבעל פה היא לבנת זהב אנכית הנמתחת מסיני למרכז החלל הפנוי. מדע הוא החקירה של החלל עצמו. כאשר שניהם נפגשים, ה"עולם נמסר" למחפש.
            </div>
            <blockquote class="fancy-quote">
            "הביטו במעשי ה'; זוהי הצורה הגבוהה ביותר של עבודה."
            </blockquote>
            
            
        </div>

</div>

        </div>

        

